#HR Analytics solution using logistic regression
#Business Understanding
#Data Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation

### Business Understanding:
#XYZ Company has about 4,000 employees, with an annual attrition rate of ~15%. 
#The company has maintained the following data regarding the employees
#Details about each employee
#Job satisfaction survey results and manager satisfaction survey results
#In time and out time

## AIM:
#The aim is to model the probability of attrition using logistic regression.  

#Data Understanding
# Install and Load the required packages
install.packages("MASS")
install.packages("car")
install.packages("e1071")
install.packages("caret", dependencies = c("Depends"))
install.packages("cowplot")
install.packages("GGally")
install.packages("lubridate")

library(dplyr)
library(MASS)
library(car)
library(e1071)
library(caret)
library(ggplot2)
library(cowplot)
library(caTools)
library(GGally)
library(ROCR)
library(tidyr)
library(stringr)
library (lubridate)

# Loading 5 files
employee_survey_data<-read.csv("employee_survey_data.csv",stringsAsFactors = F)
manager_survey_data<-read.csv("manager_survey_data.csv",stringsAsFactors = F)
general_data<-read.csv("general_data.csv",stringsAsFactors = F)
in_time <- read.csv("in_time.csv",stringsAsFactors = F)
out_time <- read.csv("out_time.csv",stringsAsFactors = F)

#Data set validation:
#1. Check the structure of the dataframes
str(employee_survey_data) # 4410 obs with 3 variables
str(manager_survey_data) #4410 obs. of  3 variables
str(general_data) #4410 obs. of  24 variables
# Some chr string variables should become factors
unique(general_data$Attrition)
unique(general_data$BusinessTravel)
unique(general_data$Department)
unique(general_data$Education)
unique(general_data$EducationField)
unique(general_data$EmployeeCount) #only value is '1'
unique(general_data$Gender)
unique(general_data$JobLevel)
unique(general_data$JobRole)
unique(general_data$MaritalStatus)
unique(general_data$Over18)  # only value is 'Y' 
unique(general_data$PercentSalaryHike)
unique(general_data$StandardHours) #only value is '8'
unique(general_data$StockOptionLevel)

#convert specific variables into factors
general_data$Attrition <- as.factor(general_data$Attrition)
general_data$BusinessTravel <- as.factor(general_data$BusinessTravel)
general_data$Department <- as.factor(general_data$Department)
general_data$EducationField <- as.factor(general_data$EducationField)
general_data$Gender <- as.factor(general_data$Gender)
general_data$JobRole <- as.factor(general_data$JobRole)
general_data$MaritalStatus<- as.factor(general_data$MaritalStatus)
general_data$Over18 <- as.factor(general_data$Over18)

#Check the summary of the data for interesting results and missing data
summary(general_data)
#missing values found
#NumCompaniesWorked has 19 NAs and TotalWorkingYears has 9 NAs
# remove missing values 
general_data <- na.omit(general_data)

#columns with no informative data need to be identified and removed. 
#Remove general_data$EmployeeCount, general_data$Over18 and general_data$StandardHours
library(caret)
summary.data.frame(general_data[,nearZeroVar(general_data)])
general_data <- general_data[,-nearZeroVar(general_data)]

#Creating dummies
general_data_char <- general_data[ , c(2 , 3 , 4 , 7 , 9 , 11 , 12)]
dummies <- data.frame(sapply(general_data_char , 
                             function(x) data.frame(model.matrix( ~x-1 , data = general_data_char))[-1]))

general_data <- cbind(general_data[, -c(2 , 3 , 4 , 7 , 9 , 11 , 12)] , dummies)

str(in_time) #4410 obs. of  262 variables
str(out_time) #4410 obs. of  262 variables
colnames(in_time) [1]  <- "EmployeeID"
colnames(out_time) [1] <- "EmployeeID"

#Calculate average working hours
#Convert the in_time and out_time from wide to long format
in_time <- gather(in_time, in_day, in_day_time, X2015.01.01 :X2015.12.31)
in_time$in_day <- str_replace(in_time$in_day, "X", "")

out_time <-  gather(out_time, out_day, out_day_time, X2015.01.01 :X2015.12.31)
out_time$out_day <- str_replace(out_time$out_day, "X", "")

#remove columns with all NA values
in_time       <- in_time[ (!is.na(in_time$in_day_time)), ]
out_time <- out_time[ (!is.na(out_time$out_day_time)), ]

#Combining in_time and out_time into one dataframe
in_out_time <- data.frame(cbind(in_time$EmployeeID,in_time$in_day_time,out_time$out_day_time ))

str(in_out_time)
#X1 and X2 are stored as factor. They need to be converted to data-time format
in_out_time$X2 <- parse_date_time(in_out_time$X2, c("Ymd_HMS"), tz="")
in_out_time$X3 <- parse_date_time(in_out_time$X3, c("Ymd_HMS"), tz="")
#Calculate the number of working hours per day
in_out_time$X4 <- difftime(in_out_time$X3, in_out_time$X2, units = c("hours"))
#calculate the average working hours
emp_avg_work_hours <- aggregate(in_out_time$X4, by = list(in_out_time$X1), mean, na.rm=TRUE)
head(emp_avg_work_hours)
#rename the columns
colnames(emp_avg_work_hours) <- c("EmployeeID", "avg_work_hrs") 
#round avg_work_hrs to 2 decimals
emp_avg_work_hours$avg_work_hrs<- round(emp_avg_work_hours$avg_work_hrs,2)

#using setdiff to verify that the data is for the same employee numbers
setdiff(general_data$EmployeeID, emp_avg_work_hours$EmployeeID) # value is 0, indicating no difference
setdiff(general_data$EmployeeID, employee_survey_data$EmployeeID) # value is 0, indicating no difference
setdiff(general_data$EmployeeID, manager_survey_data$EmployeeID) # value is 0, indicating no difference

#Merge files to create master_file
master_file<- merge(employee_survey_data,manager_survey_data,by="EmployeeID",all=F)
master_file<-merge(master_file,general_data,by="EmployeeID",all=F)
master_file<- merge(master_file,emp_avg_work_hours, by="EmployeeID",all=F)
str(master_file) #4382 obs. of 41 variables
summary(master_file)
#82 NAs, which can be removed as it is under 2% of the total observations
master_file <- na.omit(master_file)
summary(master_file) # no NA values
str(master_file) #4300 obs. of 27 variables

sum(duplicated(master_file)) # output = 0, indicating that duplication is not required

colnames(master_file)[20] <- "Attrition"
# Removing EmployeeID
master_file <- master_file[ , -1]

########################################################################
# splitting the data between train and test
set.seed(100)

indices = sample.split(master_file$Attrition, SplitRatio = 0.7)

train = master_file[indices,]

test = master_file[!(indices),]

########################################################################
# Logistic Regression: 

#Initial model
model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) 

# Stepwise selection

model_2<- stepAIC(model_1, direction="both")

summary(model_2)
vif(model_2)

#Excluding MaritalStatus.xMarried
model_3 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + EducationField.xLife.Sciences + 
                 EducationField.xMarketing + EducationField.xMedical + EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_3)
vif(model_3)

# EducationField.xLife.Sciences has high VIF, but high significance also.
# the VIF didn't change, so better to remove the variable

model_4 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently + 
                 BusinessTravel.xTravel_Rarely + 
                 EducationField.xMarketing + EducationField.xMedical + EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_4)
vif(model_4)

#Removing BusinessTravel.xTravel_Rarely

model_5 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                 EducationField.xMarketing + EducationField.xMedical + EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_5)
vif(model_5)

# cannot exclude any more variable based on vif 
# As most of them have low vif; those with higher vif are very significant and not correlated

# Removing EducationField.xMarketing 

model_6 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                 EducationField.xMedical + EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_6)
vif(model_6)

# Removing EducationField.xMedical

model_7 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                 EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_7)
vif(model_7)

# Removing EducationField.xOther

model_8 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                 EducationField.xTechnical.Degree + JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_8)
vif(model_8)

# Removing EducationField.xTechnical.Degree

model_9 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                 JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                 StockOptionLevel + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                 JobRole.xHuman.Resources + 
                 JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 avg_work_hrs, family = "binomial", data = train)
summary(model_9)
vif(model_9)

# Removing Stockoptionlevel

model_10 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + JobLevel + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xHuman.Resources + 
                  JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_10)
vif(model_10)

# Removing joblevel

model_11 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xHuman.Resources + 
                  JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_11)
vif(model_11)

# Removing JobRole.xHuman.Resources

model_12 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xManager + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_12)
vif(model_12)

# Removing JobRole.xManager 

model_13 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_13)

# Removing JobRole.xSales.Executive

model_14 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_14)

# Removing JobRole.xResearch.Director

model_15 <- glm(formula = Attrition ~ EnvironmentSatisfaction + 
                  JobSatisfaction + WorkLifeBalance + Age + NumCompaniesWorked + 
                  TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + BusinessTravel.xTravel_Frequently +
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + 
                  avg_work_hrs, family = "binomial", data = train)
summary(model_15)

########################################################################
# With 13 significant variables in the model

final_model<- model_15

#######################################################################

### Test Data ####

# predicted probabilities of Attrition 1 for test data

test_pred = predict(final_model, type = "response", 
                    newdata = test)

# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)

# Let's use the probability cutoff of 50%.

test_pred_attr <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_attr <- factor(ifelse(test$Attrition==1,"Yes","No"))


table(test_actual_attr , test_pred_attr)

test_conf <- confusionMatrix(test_pred_attr, test_actual_attr, positive = "Yes")
test_conf

# Here we need to find the probability of attrition of  an employee
# so taking the probability cutoff of 40%

test_pred_attr <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))
table(test_actual_attr , test_pred_attr)

test_conf <- confusionMatrix(test_pred_attr, test_actual_attr, positive = "Yes")
test_conf

# The accuracy of the final model with the probability cutoff of 40% is 0.85

#########################################################################################
# Let's Choose the cutoff value. 
# 

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_attr <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attr, test_actual_attr, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.003575 to 0.8633700 for plotting and initiallizing a matrix of 100 X 3.

# Summary of test probability

summary(test_pred)

s = seq(.01,.85,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.02)]


# Let's choose a cutoff value of 0.1796 for final model

test_cutoff_attr <- factor(ifelse(test_pred >=0.1796, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_churn, test_actual_churn, positive = "Yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

acc

sens

spec

View(test)
##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_attr <- ifelse(test_cutoff_attr=="Yes",1,0)
test_actual_attr <- ifelse(test_actual_attr=="Yes",1,0)


library(ROCR)
#on testing  data
pred_object_test<- prediction(test_cutoff_attr, test_actual_attr)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)


####################################################################
# Lift & Gain Chart 

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attr_decile = lift(test_actual_attr, test_pred, groups = 10)
